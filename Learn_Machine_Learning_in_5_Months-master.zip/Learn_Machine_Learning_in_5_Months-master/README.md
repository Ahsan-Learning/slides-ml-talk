# Learn_Machine_Learning_in_5_Months

This is the Curriculum for "Learn Machine Learning in 5 Months" 

# Month 1

## Week 1,2 Linear Algebra
https://www.youtube.com/watch?v=kjBOesZCoqc&index=1&list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab
https://ocw.mit.edu/courses/mathematics/18-06-linear-algebra-spring-2010/
## Week 3 Calculus
https://www.youtube.com/playlist?list=PLZHQObOWTQDMsr9K-rj53DwVRMYO3t5Yr
## Week 4 Essential Math for Machine Learning: Python Edition
https://www.edx.org/course/essential-math-for-machine-learning-python-edition-3

# Month 2

## Week 1,2,3 Probability
https://www.edx.org/course/introduction-probability-science-mitx-6-041x-2
## Week 4 Algorithms
https://www.edx.org/course/algorithm-design-analysis-pennx-sd3x

# Month 3

## Week 1 
#### Principles of Machine Learning: Python Edition 
https://www.edx.org/course/principles-of-machine-learning-python-edition-3

#### OR Principles of Machine Learning: R Edition
https://www.edx.org/course/principles-of-machine-learning-r-edition-3

#### Maths for ML every Algorithm and Model
https://www.youtube.com/watch?v=xRJCOz3AfYY&list=PL2-dafEMk2A7mu0bSksCGMJEmeddU_H4D

## Week 2 
Intro to ML (Udacity)
https://eu.udacity.com/course/intro-to-machine-learning--ud120

## Week 3-4
ML Project Ideas
https://github.com/NirantK/awesome-project-ideas

# Month 4

## Week 1,2 
## Machine Learning with Python: from Linear Models to Deep Learning
https://www.edx.org/course/machine-learning-with-python-from-linear-models-to-deep-learning

## Week 3,4
## Intro to TensorFlow for Deep Learning byTensorFlow
https://www.udacity.com/course/intro-to-tensorflow-for-deep-learning--ud187

# Month 5 

## Week 1,2
## Deep Learning with Tensorflow
https://www.edx.org/course/deep-learning-with-tensorflow

## Week 3-4 
Re-implement DL projects from Siraj Raval's github
https://github.com/llSourcell?tab=repositories
