// const add = require('add') // ES5

// import {add} from './index'; //ES6

// console.log("saad")

root = document.createElement('div')
heading = document.createElement('span')
heading.textContent = "Saad Hassan"

document.body.append(heading)


