// Print Statement
// console.log("saad")

// DATA TYPES
// Numbers

// let num = 10
// let num2 = 10.89
// console.log(typeof(num2))

// let add = num + num2
// let sub = num - num2
// let mul = num * num2
// let div = num / num2
// let mod = num % num2

// Strings

// let name = "saad"
// console.log(typeof(name))

// let age = 20

// // Implicit conversion
// let age = 20
// let add = age + name
// console.log(add)

// Template Literal
// console.log(`my name is ${name}. My age is ${age}`)

// Boolean

// let answer  = false
// console.log(typeof(answer))

// Null

// let name = null;
// console.log(typeof(name))


// Undefined

// let x;
// console.log(typeof(x))

// Arrays

// let arr = ['saad',23,true,null,78.9,"ahmed"]

// console.log(arr.length)

// for(element of arr){
//     console.log(element)
// }
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i])
// }


// Functions

// function add(num1,num2){
//     let sum = num1 + num2
//     console.log(sum)
// }

// function expression
// const add = function(num1,num2){
    // let sum = num1 + num2
    // console.log(sum)
//     return num1+num2
// }
// console.log(add(4,5))

// module.exports = add;

// const date = new Date();
// console.log(date)

// const pi = Math.PI
// console.log(pi)
// console.log(Math.sqrt(19898789))


// Conditional Statements
// == this only check value
// === this checks value and type

// let num = 12
// if (num === '12'){
//     console.log("correct")
// }
// else{
//     console.log("incorrect")
// }

// != 
// !==

// let value = 0
// switch(value){
//     case 1:
//         console.log("case 1")
//         break
//     case 2:
//         console.log("case 2")
//         break
//     default:
//         console.log("default")
// }


// Objects
