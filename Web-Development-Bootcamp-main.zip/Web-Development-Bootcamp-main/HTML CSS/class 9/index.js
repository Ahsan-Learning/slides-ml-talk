// Print function
// console.log("Hello JS")
// console.dir(document)
// // message box display

// alert("Hello You are hacked")

// variables

// var name = "saad"

// let number = 10.566

// const myname = "saad"

// number = "ali"

// console.log(name,number)

// document.getElementById("heading").style.color ="red";

// document.getElementById("btn").style.color = "blue";

// let heading = document.getElementsByClassName("title1");

// heading.style.color = "red"
// heading.style.textAlign = "center"
// heading.style.textDecoration = "none"

// for (var i=1;i<=10;i++){
//     console.log(i)
// }

// while(){

// }

// switch(condition){

// }


// if (i<2){

// }
// else{

// }

// else if(){

// }
